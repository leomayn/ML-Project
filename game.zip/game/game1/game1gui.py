import sys
import os
import builtins
import tkinter as tk

# Ensure the game package is on the path
sys.path.append(os.path.dirname(__file__))

from game.game1.game1player import Player
from game.game1.game1main import main as console_main

# --- GUI Setup ---
root = tk.Tk()
root.title("Card Game GUI")

# Info frame to display game state
info_frame = tk.Frame(root)
info_frame.pack(pady=5)

# Round label
date_label = tk.Label(info_frame, text="Round: 0", font=("Arial", 12))
date_label.grid(row=0, column=0, padx=10)
# Money label
money_label = tk.Label(info_frame, text="Money: $0", font=("Arial", 12))
money_label.grid(row=0, column=1, padx=10)

# Frames for hand and bench
hand_frame = tk.Frame(info_frame)
hand_frame.grid(row=0, column=2, padx=10)
hand_label = tk.Label(hand_frame, text="Hand:", font=("Arial", 12))
hand_label.pack(anchor="w")

bench_frame = tk.Frame(info_frame)
bench_frame.grid(row=0, column=3, padx=10)
bench_label = tk.Label(bench_frame, text="Bench:", font=("Arial", 12))
bench_label.pack(anchor="w")

# Prompt and button area
prompt_label = tk.Label(root, text="", font=("Arial", 14))
prompt_label.pack(pady=10)
button_frame = tk.Frame(root)
button_frame.pack(pady=5)
input_var = tk.StringVar()
current_player = None

# Store clickable card containers
hand_containers = []
bench_containers = []

# Action labels
action_labels = {"1": "Bench a card", "2": "Redraw hand", "3": "Sell a card", "4": "End turn"}

# Helper to draw cards
def draw_cards(frame, cards):
    # Clear existing (skip title)
    for widget in frame.winfo_children()[1:]: widget.destroy()
    global hand_containers, bench_containers
    if frame is hand_frame: hand_containers = []
    else: bench_containers = []
    for idx, card in enumerate(cards):
        container = tk.Frame(frame, width=60, height=90, bd=2, relief="raised")
        container.pack_propagate(False)
        container.pack(side="left", padx=3)
        if frame is hand_frame: hand_containers.append((container, idx))
        else: bench_containers.append((container, idx))
        # Name centered
        tk.Label(container, text=str(card.name), font=("Arial", 12)).place(relx=0.5, rely=0.5, anchor='center')
        # Cost top-right
        cost = f"${card.cost}" if hasattr(card, 'cost') else ''
        tk.Label(container, text=cost, font=("Arial", 8), bg='white').place(relx=1.0, rely=0.0, anchor='ne')

# GUI input
def gui_input(prompt):
    input_var.set("")
    prompt_label.config(text=prompt)
    for w in button_frame.winfo_children(): w.destroy()

    # Bench selection by clicking card
    if "Index in hand" in prompt and current_player:
        prompt_label.config(text="Click the card to bench:")
        for container, idx in hand_containers:
            def on_click(e, i=idx, cont=container):
                # Immediate UI move
                # Remove the card UI
                cont.destroy()
                # Add to bench UI
                card = current_player.hand[i]
                new_cont = tk.Frame(bench_frame, width=60, height=90, bd=2, relief="raised")
                new_cont.pack_propagate(False)
                new_cont.pack(side="left", padx=3)
                tk.Label(new_cont, text=str(card.name), font=("Arial", 12)).place(relx=0.5, rely=0.5, anchor='center')
                cost_text = f"${card.cost}" if hasattr(card, 'cost') else ''
                tk.Label(new_cont, text=cost_text, font=("Arial", 8), bg='white').place(relx=1.0, rely=0.0, anchor='ne')
                input_var.set(str(i))
            container.config(cursor="hand2")
            container.bind("<Button-1>", on_click)
        root.wait_variable(input_var)
        # Clean up binds
        for container, _ in hand_containers:
            container.unbind("<Button-1>")
            container.config(cursor="")
        return input_var.get()

    # Bench sell selection via click
    if "Which index to sell" in prompt and current_player:
        prompt_label.config(text="Click the card to sell:")
        for container, idx in bench_containers:
            container.config(cursor="hand2")
            container.bind("<Button-1>", lambda e, i=idx: input_var.set(str(i)))
        root.wait_variable(input_var)
        for container, _ in bench_containers:
            container.unbind("<Button-1>")
            container.config(cursor="")
        return input_var.get()

    # Action buttons
    if "Choose an action" in prompt:
        for c in action_labels:
            tk.Button(button_frame, text=action_labels[c], width=12,
                      command=lambda v=c: input_var.set(v)).pack(side="left", padx=5)
        root.wait_variable(input_var)
        return input_var.get()

    # Fallback
    entry = tk.Entry(button_frame)
    entry.pack(side="left")
    tk.Button(button_frame, text="OK", command=lambda: input_var.set(entry.get())).pack(side="left")
    root.wait_variable(input_var)
    return input_var.get()

# Monkey-patch input
builtins.input = gui_input

# Patch take_turn to update display
_original = Player.take_turn

def patched_turn(self, game):
    global current_player
    current_player = self
    # Update round and money
    rnd = getattr(game, 'round_number', getattr(game, 'round', 'N/A'))
    date_label.config(text=f"Round: {rnd}")
    money = getattr(self, 'money', getattr(self, 'total_money', 0))
    money_label.config(text=f"Money: ${money}")
    # Redraw cards
    draw_cards(hand_frame, self.hand)
    draw_cards(bench_frame, self.bench)
    root.update_idletasks()
    return _original(self, game)

Player.take_turn = patched_turn

# Start the game
if __name__ == "__main__":
    console_main()
    prompt_label.config(text="Game Over! Close window to exit.")
    for w in button_frame.winfo_children(): w.destroy()
    tk.Button(button_frame, text="Exit", command=root.destroy).pack()
    root.mainloop()
